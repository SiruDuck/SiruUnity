﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class player : MonoBehaviour
{
    public float speed;
    public bool isTouchtop;
    public bool isTouchbottom;
    public bool isTouchright;
    public bool isTouchleft;

    public float maxShotDelay;
    public float curShotDelay;
    public GameObject bulletObjA;

    public bool[] joyControl;
    public bool isControl;
    public bool isButtonA;
    void Update()
    {
        Move();
        Fire();
        Reload();
       
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
      if(collision.gameObject.tag == "Border")
        {
            switch (collision.gameObject.name)
            {
                case "top":
                    isTouchtop = true;
                    break;

                case "bottom":
                    isTouchbottom = true;
                    break;
                    
                case "right":
                    isTouchright = true;
                    break;

                case "left":
                    isTouchleft = true;
                    break;

            }
        }  
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Border")
        {
            switch (collision.gameObject.name)
            {
                case "top":
                    isTouchtop = false;
                    break;

                case "bottom":
                    isTouchbottom = false;
                    break;

                case "right":
                    isTouchright = false;
                    break;

                case "left":
                    isTouchleft = false;
                    break;

            }
        }
    }

    public void JoyPanel(int type)
    {
        for (int index = 0; index < 9; index++)
        {
            joyControl[index] = index == type; 
        }
    }

    public void JoyDown()
    {
        isControl = true;
    }
    public void JoyUp()
    {
        isControl = false;
    }


    void Move()
    {
        //#.Joy Control keybord Value
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");

        //#.Joy Control Value
        if (joyControl[0]) { h = -1; v = 1; }
        if (joyControl[1]) { h =  0; v = 1; }
        if (joyControl[2]) { h =  1; v = 1; }
        if (joyControl[3]) { h = -1; v = 0; }
        if (joyControl[4]) { h =  0; v = 0; }
        if (joyControl[5]) { h =  1; v = 0; }
        if (joyControl[6]) { h = -1; v = -1; }
        if (joyControl[7]) { h =  0; v = -1; }
        if (joyControl[8]) { h =  1; v = -1; }

        //#. ! isControl (누르고 있지 않다면 0값
        if ((isTouchright && h == 1) || (isTouchright && h == -1) || !isControl )
            h = 0;

       
        if ((isTouchtop && v == 1) || (isTouchbottom && v == -1) || !isControl)
            v = 0;

        Vector3 curPos = transform.position;
        Vector3 nextPos = new Vector3(h, v, 0) * speed * Time.deltaTime;
        transform.position = curPos + nextPos;
    }



    public void ButtonADown()
    {
        isButtonA = true;
    }
    public void ButtonAUp()
    {
        isButtonA = false;
    }





    void Fire()
    {
        //if (!Input.GetButton("Fire1"))
        //   return;

        if (!isButtonA)
            return;

        if (curShotDelay < maxShotDelay)  //장전이 안되면 리턴
            return;

        GameObject bullet1 = Instantiate(bulletObjA, transform.position, transform.rotation);
        Rigidbody2D rigid = bullet1.GetComponent<Rigidbody2D>();
        rigid.AddForce(Vector2.up * 10, ForceMode2D.Impulse);
        
        curShotDelay = 0; //한발 쏘고 장전
    }

    void Reload()
    {

        curShotDelay += Time.deltaTime;
    }
}
