﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Hplayply : MonoBehaviour
{
    public void PlayPly()
    {
        SceneManager.LoadScene("plyScenes");
    }
}
