﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{

    private void Update()
    {
        transform.position = new Vector3(transform.position.x, transform.position.y +0.1f, transform.position.z);
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "BorderBullet")
        {
            Destroy(gameObject);
        }

        if (collision.gameObject.tag == "monster")
        {
            Destroy(gameObject);
        }
    }

}
