﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class makecloud : MonoBehaviour
{
    public GameObject clude;
    float timer = 0;
    public float timeDiff;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if(timer > timeDiff)
        {
            GameObject newcloud = Instantiate(clude);
            newcloud.transform.position = new Vector3(Random.Range(-2.14f, 2.85f), 6.36f, 0);
            timer = 0;
            Destroy(newcloud,6.0f);
        }
        
    }
}
