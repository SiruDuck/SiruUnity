﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Makemon : MonoBehaviour
{
    public GameObject monster1;
    float timer = 0;
    public float timeDiff;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > timeDiff)
        {
            GameObject newmonster1 = Instantiate(monster1);
            newmonster1.transform.position = new Vector3(Random.Range(-2.14f, 2.77f), 7.0f, 0);
            timer = 0;
            Destroy(newmonster1, 6.0f);
        }

    }
}
