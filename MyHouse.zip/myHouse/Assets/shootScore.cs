﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class shootScore : MonoBehaviour
{
    public static int score = 0; //다른 스크립트에서도 점수를 사용하기위해
    public static int bestScore = 0;
    // Start is called before the first frame update
    void Start()
    {   
        score = 0;  //게임이 다시 시작할 때 0점으로 초기화
    }

    // Update is called once per frame
    void Update()
    {   
        GetComponent<Text>().text = score.ToString(); //스트링자료형 변환
        
    }
}
