﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Scoreup : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "bool")
        {
            Destroy(gameObject);
            shootScore.score++;
            Gold.goldscore++;
        }
        if (collision.gameObject.tag == "player")
        {
            Destroy(gameObject);
            if (shootScore.score > shootScore.bestScore)
            {
                shootScore.bestScore = shootScore.score;
            }
            SceneManager.LoadScene("outScene");
            
        }
    }



}
